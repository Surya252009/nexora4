package com.nexora.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.*
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

class MainActivity : ComponentActivity(), SensorEventListener {
    private lateinit var web: WebView
    private lateinit var sensorManager: SensorManager
    private lateinit var permissionLauncher: ActivityResultLauncher<Set<String>>
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val sensorValues = mutableMapOf<String, FloatArray>()
    private val sensorMap = mapOf(
        Sensor.TYPE_ACCELEROMETER to "accelerometer",
        Sensor.TYPE_GYROSCOPE to "gyroscope",
        Sensor.TYPE_MAGNETIC_FIELD to "magnetometer",
        Sensor.TYPE_LIGHT to "light",
        Sensor.TYPE_PROXIMITY to "proximity",
        Sensor.TYPE_STEP_COUNTER to "stepCounter"
    )
    private val permissions = setOf(
        HealthPermission.getReadPermission(StepsRecord::class),
        HealthPermission.getReadPermission(HeartRateRecord::class),
        HealthPermission.getReadPermission(SleepSessionRecord::class),
        HealthPermission.getReadPermission(OxygenSaturationRecord::class),
        HealthPermission.getReadPermission(WeightRecord::class)
    )

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        permissionLauncher = registerForActivityResult(
            PermissionController.createRequestPermissionResultContract()
        ) { granted ->
            if (permissions.all { it in granted }) {
                notifyJs("NexoraHealthPermissionResult", JSONObject().put("granted", true).toString())
                syncHealthConnect()
            } else {
                notifyJs("NexoraHealthPermissionResult", JSONObject().put("granted", false)
                    .put("error", "Allow the requested Health Connect data permissions.").toString())
            }
        }
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "NexoraNative")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class Bridge {
        @JavascriptInterface fun requestHealthConnectPermissions() { runOnUiThread { requestHealthPermissions() } }
        @JavascriptInterface fun syncHealthConnectData() { runOnUiThread { syncHealthConnect() } }
        @JavascriptInterface fun openHealthConnectSettings() {
            runOnUiThread {
                try { startActivity(Intent("androidx.health.ACTION_HEALTH_CONNECT_SETTINGS")) }
                catch (_: Exception) { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) }
            }
        }
        @JavascriptInterface fun getPlatformInfo(): String =
            JSONObject().put("platform","android").put("nativeSensors",true).put("healthConnect",true).toString()
        @JavascriptInterface fun getSensorAvailability(): String {
            val j=JSONObject()
            sensorMap.forEach { (type,name) -> j.put(name, sensorManager.getDefaultSensor(type)!=null) }
            return j.put("platform","android").toString()
        }
        @JavascriptInterface fun getSensorSnapshot(): String {
            val j=JSONObject()
            synchronized(sensorValues) { sensorValues.forEach { (k,v) -> val a=JSONArray(); v.forEach { a.put(it.toDouble()) }; j.put(k,a) } }
            return j.toString()
        }
        @JavascriptInterface fun startPhoneSensors() {
            runOnUiThread {
                if (Build.VERSION.SDK_INT >= 29 && checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.ACTIVITY_RECOGNITION), 402)
                } else registerSensors()
            }
        }
    }

    private fun registerSensors() {
        sensorMap.forEach { (type,_) ->
            if (type == Sensor.TYPE_STEP_COUNTER && Build.VERSION.SDK_INT >= 29 &&
                checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED) return@forEach
            sensorManager.getDefaultSensor(type)?.let { sensorManager.registerListener(this,it,SensorManager.SENSOR_DELAY_UI) }
        }
    }

    private fun requestHealthPermissions() {
        when (HealthConnectClient.getSdkStatus(this)) {
            HealthConnectClient.SDK_AVAILABLE -> scope.launch {
                try {
                    val client=HealthConnectClient.getOrCreate(this@MainActivity)
                    val current=client.permissionController.getGrantedPermissions()
                    val missing=permissions-current
                    if (missing.isEmpty()) syncHealthConnect() else permissionLauncher.launch(missing)
                } catch(e:Exception) {
                    notifyJs("NexoraHealthPermissionResult", JSONObject().put("error",e.message ?: "Health Connect permission request failed").toString())
                }
            }
            HealthConnectClient.SDK_UNAVAILABLE_PROVIDER_UPDATE_REQUIRED -> {
                notifyJs("NexoraHealthPermissionResult", JSONObject().put("error","Install or update Health Connect, then retry.").toString())
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.google.android.apps.healthdata"))) } catch (_:Exception) {}
            }
            else -> notifyJs("NexoraHealthPermissionResult", JSONObject().put("error","Health Connect is unavailable on this device.").toString())
        }
    }

    private fun syncHealthConnect() {
        scope.launch {
            try {
                val client=HealthConnectClient.getOrCreate(this@MainActivity)
                val granted=client.permissionController.getGrantedPermissions()
                val missing=permissions-granted
                if (missing.isNotEmpty()) { permissionLauncher.launch(missing); return@launch }
                val now=Instant.now()
                val dayStart=LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant()
                val recent=now.minusSeconds(30L*24*60*60)
                val result=withContext(Dispatchers.IO) {
                    val out=JSONObject()
                    val steps=client.readRecords(ReadRecordsRequest(StepsRecord::class, TimeRangeFilter.between(dayStart,now))).records.sumOf { it.count }
                    out.put("steps",steps)
                    val hr=client.readRecords(ReadRecordsRequest(HeartRateRecord::class,TimeRangeFilter.after(recent))).records.flatMap { it.samples }.maxByOrNull { it.time }
                    hr?.let { out.put("heartRate",it.beatsPerMinute.toDouble()) }
                    val sleep=client.readRecords(ReadRecordsRequest(SleepSessionRecord::class,TimeRangeFilter.after(recent))).records
                    if(sleep.isNotEmpty()) out.put("sleepHours",sleep.sumOf { java.time.Duration.between(it.startTime,it.endTime).toMillis() }/3600000.0)
                    val oxygen=client.readRecords(ReadRecordsRequest(OxygenSaturationRecord::class,TimeRangeFilter.after(recent))).records.maxByOrNull { it.time }
                    oxygen?.let { out.put("spo2",it.percentage.value) }
                    val weight=client.readRecords(ReadRecordsRequest(WeightRecord::class,TimeRangeFilter.after(recent))).records.maxByOrNull { it.time }
                    weight?.let { out.put("weight",it.weight.inKilograms) }
                    out.put("syncedAt",java.time.format.DateTimeFormatter.ofPattern("HH:mm").withZone(ZoneId.systemDefault()).format(now))
                    out
                }
                notifyJs("NexoraHealthDataResult",result.toString())
            } catch(e:Exception) {
                notifyJs("NexoraHealthDataResult",JSONObject().put("error",e.message ?: "Health Connect sync failed").toString())
            }
        }
    }

    private fun notifyJs(callback:String,payload:String) {
        if (!::web.isInitialized) return
        val safe=JSONObject.quote(payload)
        runOnUiThread { web.evaluateJavascript("window.$callback && window.$callback($safe);",null) }
    }
    override fun onSensorChanged(event:SensorEvent) {
        val name=sensorMap[event.sensor.type] ?: return
        synchronized(sensorValues) { sensorValues[name]=event.values.clone() }
    }
    override fun onAccuracyChanged(sensor:Sensor?,accuracy:Int) {}
    override fun onRequestPermissionsResult(requestCode:Int,permissions:Array<out String>,grantResults:IntArray) {
        super.onRequestPermissionsResult(requestCode,permissions,grantResults)
        if(requestCode==402 && grantResults.firstOrNull()==PackageManager.PERMISSION_GRANTED) registerSensors()
    }
    override fun onDestroy() { if(::sensorManager.isInitialized) sensorManager.unregisterListener(this); if(::web.isInitialized) web.destroy(); super.onDestroy() }
}
